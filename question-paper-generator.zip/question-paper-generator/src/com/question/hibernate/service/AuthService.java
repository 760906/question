package com.question.hibernate.service;


import java.util.List;


import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.orm.hibernate5.HibernateTemplate;


import com.question.hbm.pojo.Question;



public class AuthService {


	private HibernateTemplate hibernateTemplate;
	
	private static Logger log = Logger.getLogger(AuthService.class);
	
	  public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
	        this.hibernateTemplate = hibernateTemplate;
	    }
	
	  @SuppressWarnings({ "unchecked", "deprecation" })
	public List<Question> fetchQuestion(String skill,String level)
	  {
		  log.info("Fetching question from the database");
		  List<Question> ques = null;
		  try{
			  String sqlQuery = "from Question where skill_set=? and competency_level=? order by rand()"; 
			  
			  System.out.println("In the authentication service...user entered data " + skill + " pwd "+level);
			 
			  ques = (List<Question>) hibernateTemplate.find(sqlQuery, skill, level);
			  ques=ques.subList(0, 20);
			  if(ques != null)
	            {
	            	System.out.println("Question obj is not null... ");
	            }
		  }
		  catch(Exception e)
		  {
			  System.out.println("Exception occur during Fetching question :"+e);
		  }
		  
		  return ques;
	  }
	  
}
