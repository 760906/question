package com.question.ctrl;

import java.util.List;

import org.apache.jasper.tagplugins.jstl.core.ForEach;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
 
import com.question.hibernate.service.AuthService;
import com.question.hbm.pojo.Question;
 
@Component
@Controller
@RequestMapping("/user")
public class QuestionCtrl {
 
    @Autowired
    private AuthService authenticateService;            // This will auto-inject the authentication service into the controller.
 
    private static Logger log = Logger.getLogger(QuestionCtrl.class);

    
    @RequestMapping(value = "/search", method = RequestMethod.GET)
    public ModelAndView forwardeSearch() {
    	ModelAndView model=new ModelAndView();
    	model.setViewName("searchskill");
           return model;
    }
    
    // Checks if the user credentials are valid or not.
    @RequestMapping(value = "/ins", method = RequestMethod.POST)
    public ModelAndView forwardInstruction(@RequestParam("skill")String skill, @RequestParam("level")String level) {
    	ModelAndView model=new ModelAndView();
   model.addObject("skill",skill);
   model.addObject("level",level);
	model.setViewName("instruction");
      return model;
    }
    @RequestMapping(value = "/test", method = RequestMethod.POST)
    public ModelAndView forwardTest(@RequestParam("skill")String skill, @RequestParam("level")String level) {
    	ModelAndView model=new ModelAndView();
    	List<Question> ques=authenticateService.fetchQuestion(skill, level);
    	model.addObject("questionList",ques);
    	model.setViewName("test");
           return model;
    }
    
    @RequestMapping(value = "/summary", method = RequestMethod.POST)
    public ModelAndView forwardSummary(@RequestParam("ans")String ans) {
    	ModelAndView model=new ModelAndView();
    	model.addObject("ans",ans);
    	model.setViewName("testsummary");
           return model;
    }
    
    @RequestMapping(value = "/404", method = RequestMethod.GET)
    public ModelAndView forwardeError() {
    	ModelAndView model=new ModelAndView();
    	model.setViewName("error");
           return model;
    }
        
}
